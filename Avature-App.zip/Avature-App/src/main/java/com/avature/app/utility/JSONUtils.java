/** 
* Copyright © 2017 - Avature Documentation
*/

package com.avature.app.utility;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * JSONUtil is static class having utility methods to convert JSON object to java object and vice versa
 * 
 * @author Sudhanshu
 *
 */
public class JSONUtils {

	private static ObjectMapper objMapper = null;
	
	static {
		// Executes at the time of class loading only
		objMapper = new ObjectMapper();
	}

	/**
	 * This method converts JSON string to Class object
	 * 
	 * @param jsonStr
	 * @param objClass
	 * @return corresponding java object for JSON string
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public static <T> T convertToObject(String jsonStr, Class<T> objClass)
			throws JsonParseException, JsonMappingException, IOException {

		return convertToObject(jsonStr, objClass,true);
	}

	/**
	 * This method converts JSON string to Class object
	 * 
	 * @param jsonStr
	 * @param objClass
	 * @param fail on unknown properties default true
	 * @return corresponding java object for JSON string
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public static <T> T convertToObject(String jsonStr, Class<T> objClass, boolean failOnUnknowProperties)
			throws JsonParseException, JsonMappingException, IOException {

		objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, failOnUnknowProperties);
		return objMapper.readValue(jsonStr, objClass);
	}

	 
	/**
	 * This method converts Class object to JSON string
	 * 
	 * @param object
	 * @return corresponding JSON object for JSON string
	 * @throws JsonProcessingException
	 */
	public static String convertToJSON(Object object) throws JsonProcessingException {

		return objMapper.writeValueAsString(object);
	}
}
