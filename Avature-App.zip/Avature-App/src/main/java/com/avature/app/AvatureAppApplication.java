/** 
* Copyright © 2017 - Avature Documentation
*/

package com.avature.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//,exclude = {SecurityAutoConfiguration.class}
@SpringBootApplication(scanBasePackages= {"com.avature.app"})
public class AvatureAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvatureAppApplication.class, args);
	}
	
}//class
