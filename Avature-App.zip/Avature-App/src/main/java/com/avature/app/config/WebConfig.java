/** 
* Copyright © 2017 - Avature Documentation
*/

package com.avature.app.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Web configuration for controller
 * 
 * @author Sudhanhsu
 *
 */
@Configuration
@EnableWebMvc
public class WebConfig extends WebMvcConfigurerAdapter {
	
//	@Override
//	public void addCorsMappings(CorsRegistry registry) {
//		registry.addMapping("/**").allowedOrigins("*").allowedMethods("*").allowedHeaders("*")
//				// .exposedHeaders("header1", "header2")
//				.allowCredentials(true).maxAge(3600);
//	}

}
