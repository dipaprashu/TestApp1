/** 
* Copyright © 2017 - Avature Documentation
*/

package com.avature.app.initializer;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * WebSecurityInitializer to initialize the spring web security
 * 
 * @author Sudhanshu
 */
public class WebSecurityInitializer extends AbstractSecurityWebApplicationInitializer{

}
