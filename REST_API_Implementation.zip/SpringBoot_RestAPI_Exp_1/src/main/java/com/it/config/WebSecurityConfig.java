package com.it.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.access.channel.ChannelProcessingFilter;
import org.springframework.web.cors.CorsUtils;

import com.it.filter.CORSFilter;
import com.it.service.UserServiceImpl;

@Configuration
@EnableWebSecurity
//@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	private static String REALM = "WEB_APP_REALM";

	@Autowired
	private CustomBasicAuthenticationEntryPoint customBasicAuthenticationEntryPoint;

	@Autowired
	UserServiceImpl userimpl;

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {

		auth.inMemoryAuthentication().withUser("admin").password(this.passwordEncoder().encode("p$$d")).roles("ADMIN"
		/* UserRoleStatusConstants.ROLE_ADMIN */);
		//auth.inMemoryAuthentication().withUser("user").password(this.passwordEncoder().encode("user1")).roles("USER");
		// auth.inMemoryAuthentication().withUser("user").password("p$$d").roles(AppRolesConstant.ROLE_USER);
		// auth.userDetailsService(userimpl);
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().authorizeRequests()
				.requestMatchers(CorsUtils::isCorsRequest).permitAll().antMatchers("/*")
				.access("hasRole('ADMIN') or hasRole('USER')").anyRequest().authenticated().and().httpBasic()
				.realmName(REALM).authenticationEntryPoint(customBasicAuthenticationEntryPoint).and().csrf().disable()
				.addFilterBefore(new CORSFilter(), ChannelProcessingFilter.class);
	}

	@Override
	public void configure(WebSecurity web) throws Exception { 
		web.ignoring().antMatchers(HttpMethod.OPTIONS, "/**");
	}

	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
		return bCryptPasswordEncoder;
	}
	
}//class