package com.it.initializer;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.it.SpringBootRestApiExpApplication;


/**
 * It is needed to run a SpringApplication from a WAR deployment
 * 
 * @author Sudhanshu
 *
 */

public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(SpringBootRestApiExpApplication.class);
	}

}//class